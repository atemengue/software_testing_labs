import {expect, it, describe} from 'vitest'
import {
    InvalidEventNameError,
    InvalidEventPriceError,
    InvalidReferralCodeError,
    InvalidUsernameError,
    UserHasAccountError
} from '../../js/error-handling/exceptions';

describe('Exceptions', () => {
    it('should create an InvalidEventNameError with a custom message', () => {
        const errorMessage = 'Invalid event name';
        const error = new InvalidEventNameError(errorMessage);
        expect(error.message).toBe(errorMessage);
    });

    it('should create an InvalidEventPriceError with a custom message', () => {
        const errorMessage = 'Invalid event price';
        const error = new InvalidEventPriceError(errorMessage);
        expect(error.message).toBe(errorMessage);
    });

    it('should create an InvalidReferralCodeError with a custom message', () => {
        const errorMessage = 'Invalid referral code';
        const error = new InvalidReferralCodeError(errorMessage);
        expect(error.message).toBe(errorMessage);
    });

    it('should create an InvalidUsernameError with a custom message', () => {
        const errorMessage = 'Invalid username';
        const error = new InvalidUsernameError(errorMessage);
        expect(error.message).toBe(errorMessage);
    });

    it('should create a UserHasAccountError with a custom message', () => {
        const errorMessage = 'User already has an account';
        const error = new UserHasAccountError(errorMessage);
        expect(error.message).toBe(errorMessage);
    });
});
