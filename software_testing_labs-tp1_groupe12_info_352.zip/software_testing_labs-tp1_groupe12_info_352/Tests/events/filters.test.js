import { describe, it, expect } from 'vitest';
import { today, next7Days, next30Days } from '../../js/events/filters';
import { Event } from '../../js/events/event';

describe('Event Filters', () => {
  describe('today', () => {
    it('should return true if event date is today', () => {
      const todayDate = new Date();
      const event = new Event(1, 'Concert', 10, 10, 10, todayDate);
      expect(today(event)).toBe(true);
    });

    it('should return false if event date is not today', () => {
      const yesterdayDate = new Date();
      yesterdayDate.setDate(yesterdayDate.getDate() - 1);
      const event = new Event(1, 'Concert', 10, 10, 10, yesterdayDate);
      expect(today(event)).toBe(false);
    });
  });

  describe('next7Days', () => {
    it('should return true if event date is within the next 7 days', () => {
      const todayDate = new Date();
      const tomorrowDate = new Date();
      tomorrowDate.setDate(tomorrowDate.getDate() + 1);
      const event = new Event(1, 'Concert', 10, 10, 10, tomorrowDate);
      expect(next7Days(event)).toBe(true);
    });

    it('should return false if event date is more than 7 days in the future', () => {
      const nextWeekDate = new Date();
      nextWeekDate.setDate(nextWeekDate.getDate() + 8);
      const event = new Event(1, 'Concert', 10, 10, 10, nextWeekDate);
      expect(next7Days(event)).toBe(false);
    });

    it('should return false if event date is in the past', () => {
      const yesterdayDate = new Date();
      yesterdayDate.setDate(yesterdayDate.getDate() - 1);
      const event = new Event(1, 'Concert', 10, 10, 10, yesterdayDate);
      expect(next7Days(event)).toBe(false);
    });
  });

  describe('next30Days', () => {
    it('should return true if event date is within the next 30 days', () => {
      const todayDate = new Date();
      const nextMonthDate = new Date();
      nextMonthDate.setDate(nextMonthDate.getDate() + 15);
      const event = new Event(1, 'Concert', 10, 10, 10, nextMonthDate);
      expect(next30Days(event)).toBe(true);
    });

    it('should return false if event date is more than 30 days in the future', () => {
      const nextMonthDate = new Date();
      nextMonthDate.setDate(nextMonthDate.getDate() + 31);
      const event = new Event(1, 'Concert', 10, 10, 10, nextMonthDate);
      expect(next30Days(event)).toBe(false);
    });

    it('should return false if event date is in the past', () => {
      const yesterdayDate = new Date();
      yesterdayDate.setDate(yesterdayDate.getDate() - 1);
      const event = new Event(1, 'Concert', 10, 10, 10, yesterdayDate);
      expect(next30Days(event)).toBe(false);
    });
  });
});