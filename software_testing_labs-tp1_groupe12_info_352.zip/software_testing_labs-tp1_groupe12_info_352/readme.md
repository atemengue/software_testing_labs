## TP1: Software Testing

### INF352

## GROUPE 12

## LISTE DES PARTICIPANTS



<ul>
<li>
  <h3>AWATI MAFOUO SUZY IVANA: 21T2306</h3>
</li> 
<li>
  <h3>AMBASSA GUY MATTHIEU : 20U2654</h3>
</li> 
<li>
  <h3>NGAH NOMO GUY ROGER: 20U2610</h3>
</li> 
<li>
  <h3>KENMOE SIMO BORIS: 19M2066 </h3>
</li> 
</ul>


