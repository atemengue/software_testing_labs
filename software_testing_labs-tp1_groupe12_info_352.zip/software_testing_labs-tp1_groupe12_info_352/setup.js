// setup.js
import { vi } from 'vitest';

// Configurez un mock pour une fonction globale
global.fetch = vi.fn(() => Promise.resolve({
  json: () => Promise.resolve({ data: 'Mock data' }),
}));

