import {describe,it,test,expect, expectTypeOf} from 'vitest'
import {getCoupons,calculateDiscount,isPriceInRange,isValidUsername} from './core'

let tab = [];
let a = getCoupons();
  for(let prop in a[0]){
    if(a[0].hasOwnProperty(prop)){
        tab.push(prop);
    }
  }


describe('afficher coupons',()=>{
    test("doit me retourner un tableau d'object",()=>
    {  
        expect(typeof getCoupons()).toBe('object')
    })

    it("doit me retourner un tableau d'objet ayant la propriete code ",()=>
    { 
    expect(a[0]).toHaveProperty('code')
    expect(typeof a[0].code).toBe('string')
    expect(a[0]).toBeTruthy()
    })

    
    it("doit me retourner un tableau d'objet ayant le propriete code ",()=>
        { 
        expect(a[0]).toHaveProperty('discount')
        expect(typeof a[0].discount).toBe('number')
        expect(a[0].discount).toBeGreaterThan(0)
        expect(a[0].discount).toBeLessThan(1)
        })

})



describe('calculateDiscount',()=>
{
    test("doit me retourner Invalid price si la valeur du prix est inferieur a 0",
        ()=>{
            expect(calculateDiscount(-10,'SAVE10')).toMatch(/invalid/i)
           
        }
    )

    it("doit me retourner Invalid price si la valeur du prix n'est pas un nombre",() =>{
        expect(calculateDiscount('jafh',"SAVE10")).toMatch(/invalid/i)
    })

    it("doit me retourner Invalid discount code si discountCode n' est pas une chaine de caractere",()=>{
        expect(calculateDiscount(10,10)).toMatch(/invalid/i)
        
    })

    it("doit me retourner 9 si discountCode est correct",()=>{
        expect(calculateDiscount(10,'SAVE10')).toBe(9)
        
    })

    it("doit me retourner 8 si price  est correct",()=>{
        expect(calculateDiscount(10,'SAVE20')).toBe(8)
        
    })
})

describe('isPriceInRange test suite',() => {
 it.each([{scenario:'price < min', price:-10, min : 0, max : 100, resultat : false},
 {scenario:'price > max', price: 110, min : 0, max : 100, resultat : false},
 {scenario:'price entre min et max ', price: 10, min : 0, max : 100, resultat : true},
 {scenario:'price = min', price:0, min : 0, max : 100, resultat : true},
 {scenario:'price = max', price:100, min : 0, max : 100, resultat : true}
 ])('doit me retourner $resultat si $scenario',({price,min,max,resultat}) => {
    expect(isPriceInRange(price,min,max)).toBe(resultat)
 })
})

