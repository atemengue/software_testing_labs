
import { expect, it,describe } from 'vitest'
import { grade,mark } from './grade'


describe('boundary value testing',()=>{

    let valid = 'valid';
    let invalid = 'Invalid Range';

    let cc_range = [0,20];
    let tp_range = [0,30];
    let ee_range = [0,50];
    
    let cc = -1

    it(`should return ${invalid} if cc = ${cc}`,()=>{
        
        expect(mark(cc,...cc_range)).toMatch(invalid)
    })
    cc = 15

    it(`should return ${valid} if cc = ${cc}`,()=>{
        
        expect(mark(cc,...cc_range)).toMatch(valid)
    })

    cc = 21

    it(`should return ${invalid} if cc = ${cc}`,()=>{
        
        expect(mark(cc,...cc_range)).toMatch(invalid)
    })

    let tp = -2

    it(`should return ${invalid} if tp = ${tp}`,()=>{
        
        expect(mark(tp,...tp_range)).toMatch(invalid)
    })
    tp  = 25

    it(`should return ${valid} if tp = ${tp}`,()=>{
        
        expect(mark(tp,...tp_range)).toMatch(valid)
    })

    tp = 35

    it(`should return ${invalid} if tp = ${tp}`,()=>{
        
        expect(mark(tp,...tp_range)).toMatch(invalid)
    })


    let ee = -2

    it(`should return ${invalid} if ee = ${ee}`,()=>{
        
        expect(mark(ee,...ee_range)).toMatch(invalid)
    })
    ee  = 25

    it(`should return ${valid} if ee = ${ee}`,()=>{
        
        expect(mark(ee,...ee_range)).toMatch(valid)
    })

    ee = 55

    it(`should return ${invalid} if ee = ${ee}`,()=>{
        
        expect(mark(ee,...ee_range)).toMatch(invalid)
    })
})

describe.each([
    {cc: "-1", tp: -2, ee: 10, expected: 'Invalid parameters' },
    {cc: -1, tp: -2, ee: 10, expected: 'Invalid range' },
    {cc: 10, tp: 15, ee: 10, expected: 'CANT' },
    {cc: 10, tp: 20, ee: 20, expected: 'CA' }

])('grade($cc,$tp,$ee)', ({cc,tp,ee,expected})=>{
    
    
    it(`should return ${expected}`,()=>{
        expect(grade(cc,tp,ee)).toMatch(expected)
    })

    
})