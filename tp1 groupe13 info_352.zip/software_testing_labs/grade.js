
function sum(cc,tp,ee){
    return cc+tp+ee;
    //return -1
}

export function grade(cc, tp, ee){

    if( typeof cc != 'number' || typeof tp != 'number' || typeof ee != 'number' ){
       
        return 'Invalid parameters';
    }

    if((cc < 0 || cc > 20) || (tp < 0 || tp > 30) || (ee < 0 || ee > 50)){
        return 'Invalid range'
    }

    let total = sum(cc,tp,ee)

    if(total < 35){
        return 'NC';
    }
    else if(total >= 35 && total <= 49){
        return 'CANT';
    }
    else if(total >= 50){
        return 'CA'

    }
}

export function mark(cc,a,b){

    if(typeof cc != 'number'){
        return 'Invalid parameter';
    }

    if(cc < a || cc > b){
        return 'Invalid Range';
    }
    else{
        return 'valid';
    }
}