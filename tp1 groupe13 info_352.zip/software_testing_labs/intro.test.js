// importing neccessary modules
import {test,expect,describe,it} from 'vitest'
import { max,add } from './intro'
import { calculateMoyenne,fizzBuzz} from './intro'

//Testsuite
let a = 1
let b = 2

describe("Max function",()=>{
    test("should return the sum of 1 and 2",()=>{
        expect(max(a,b)).toBe(2)
    })
})
// L'approach DDT : Ecrire le test avant le code en lui meme:
describe("calculate moyenne",()=>{
    // First test case
    it("Should return NAN if array is empty",()=>{
        // Ecris simplement le test case

        let resultatactuel = calculateMoyenne([])
        expect(resultatactuel).toBe(NaN)
    })
    // second test case
    it("should return element is array",()=>{
        expect(calculateMoyenne([2])).toBe(2)
    })
    it("should return average of n elements",()=>{
        let tab = [1,2,3]

        // Appel de fonction
        let resultatactuel = calculateMoyenne(tab)

        expect(resultatactuel).toBe(2)
    })
})


//fonction fizzBuzz

describe('fizzBuzz testsuite',() => {
    it('doit me retourner fizzBuzz si 15 est divisible par 3 et par 5 ',() => {
        let nb4 =15;
        expect(fizzBuzz(nb4)).toBe('FizzBuzz')
    })
    it('doit me retourner Fizz si 9 est divisible par 3',() => {
        let nb1 = 9
        expect(fizzBuzz(nb1)).toBe('Fizz')
    })
    it('doit me retourner Buzz si 25 est divisible par  5',() => {
        let nb2= 25
        expect(fizzBuzz(nb2)).toBe('Buzz')
    })
    test("doit me retourner une chaine de caractere si 11 n'est pas divisible par 5 et par 3",() => {
       let nb5 = 11;
       expect(fizzBuzz(nb5)).toEqual('11')
    })
})