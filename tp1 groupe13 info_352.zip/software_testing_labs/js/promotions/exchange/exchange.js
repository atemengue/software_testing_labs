import exchangeRateProvider from './exchangeRateProvider';

export default function getExchangeRate(currencyCode, callback) {

    const exchangeRate = exchangeRateProvider.callExchangeRateProvider(currencyCode)
    // const exchangeRate = await exchangeRateProvider.callExchangeRateProvider(currencyCode)
    const response = {
        "originalCurrency": "GBP",
        "newCurrency": currencyCode,
        "exchangeRate": exchangeRate
    }
    callback(response);
}
