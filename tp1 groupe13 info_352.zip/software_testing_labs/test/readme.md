#TP software testing

```**
Ce document decrit les test realise par le groupe 13  de software testing dans le cadre d'un apretissage au test logiciel

```**
# Membre du groupe 
***
LEUGUEM DJOUWA FRANCK RHUNEL 21T2824
KENFACKNGANKAM ROSTAND HEROLD 21T2279
***

#
OBJECTIF:
**
 Le but est d'effectuer un ensemble de test sur des fonctions en js
**
#prerequis
    ***
Avoir installe :
    -NodeJS version: 20.11.0
    -un editeur de code
    -un outil d'automatisaton des test(VITEST)
    -avoir une copie du projet initial
Posseder:
    Des base en JAVAScript et connaitre les syntaxe de node js et vitest

    ***


#installation
    ***
    telecharger le setup sur chrome et suivre le processus d'installation
    recuperer le projet initial a l'adresse https://github.com/atemengue/software_testing_labs
    ***



#executer les tests 
    ***
    Pour executer les test ouvrir un terminal dans le dossier contenant le  projet 
    allez dans le dossier test a l'aide de la commande cd test
    Executer la commande `npm run test` pour lancer les test 
    ***