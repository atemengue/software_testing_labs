import { expect,test,it,describe } from "vitest";
import {add,subtract,multiply,divide,isEqual} from './intro'


describe('test suite',()=>{
    it('doit me retourner la valeur de la somme de 2 nombres',()=>{
        

        expect(add(3,7)).toBe(10)
    })

    it('doit me retourner le reste de 2  nombres',()=>
    {
        expect(subtract(10,5)).toBe(5)
    })

    test('doit me retourner le produit de 2 nombres',()=>
    {
        expect(multiply(2,9)).toBe(18)
    })

    test('doit me retourner le quoitient de 2 nombres',()=>
    {
        expect(divide(6,2)).toBe(3)
    })

    it('doit me retourner l egalite  entre 2 nombres si les 2 on meme valeurs',()=>
    {
        expect(isEqual(2,2)).toBe(2===2)
    })
})