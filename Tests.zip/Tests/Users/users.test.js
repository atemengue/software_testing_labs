// tests/users.test.js
import {expect, it, describe} from 'vitest'
import { User, userExists, createUserId } from '../../js/users/users';

describe('User Class', () => {
  it('should create a new User instance with correct properties', () => {
    const user = new User(1, 'testuser');
    expect(user.id).toBe(1);
    expect(user.username).toBe('testuser');
    expect(user.isPremium).toBe(false);
  });
});

describe('userExists', () => {
  it('should return true if username exists', async () => {
    const exists = await userExists('newuser1@pluralsight.com');
    expect(exists).toBe(true);
  });

  it('should return false if username does not exist', async () => {
    const exists = await userExists('nonexistentuser@example.com');
    expect(exists).toBe(false);
  });
});

describe('createUserId', () => {
  it('should return a unique user ID', () => {
    const userId = createUserId();
    expect(userId).toBe(2); 
  });
});