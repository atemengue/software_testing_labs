import { describe, it, expect } from 'vitest';
import getEvents from '../../js/events/search';
import { Event } from '../../js/events/event';

describe('Search Events', () => {
  it('should return an empty array if no events are provided', () => {
    const events = [];
    const searchPredicate = () => true; // Always true predicate
    const filteredEvents = getEvents(events, searchPredicate);
    expect(filteredEvents).toEqual([]);
  });

  it('should return all events if the search predicate is always true', () => {
    const events = [
      new Event(1, 'Concert 1', 10, 10, 10, new Date()),
      new Event(2, 'Concert 2', 20, 20, 20, new Date()),
    ];
    const searchPredicate = () => true; // Always true predicate
    const filteredEvents = getEvents(events, searchPredicate);
    expect(filteredEvents).toEqual(events);
  });

  it('should return a filtered array of events based on the search predicate', () => {
    const events = [
      new Event(1, 'Concert 1', 10, 10, 10, new Date()),
      new Event(2, 'Concert 2', 20, 20, 20, new Date()),
      new Event(3, 'Theater Show', 30, 30, 30, new Date()),
    ];

    const searchPredicate = (event) => event.name.includes('Concert');
    const filteredEvents = getEvents(events, searchPredicate);
    expect(filteredEvents).toEqual([
      new Event(1, 'Concert 1', 10, 10, 10, new Date()),
      new Event(2, 'Concert 2', 20, 20, 20, new Date()),
    ]);
  });
});