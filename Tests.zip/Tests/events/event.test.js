
import { describe, it, expect } from 'vitest';
import { Event, isSoldOut, getTagLine, createEvent } from '../../js/events/event';
import { InvalidEventNameError, InvalidEventPriceError } from '../../js/error-handling/exceptions';

describe('Event', () => {
  describe('isSoldOut', () => {
    it('should return true if ticketsRemaining is 0', () => {
      const event = new Event(1, 'Concert', 10, 10, 0, new Date());
      expect(isSoldOut(event)).toBe(true);
    });

    it('should return false if ticketsRemaining is not 0', () => {
      const event = new Event(1, 'Concert', 10, 10, 5, new Date());
      expect(isSoldOut(event)).toBe(false);
    });
  });

  describe('getTagLine', () => {
    it('should return "Event Sold Out!" if event is sold out', () => {
      const event = new Event(1, 'Concert', 10, 10, 0, new Date());
      expect(getTagLine(event, 5, false)).toBe('Event Sold Out!');
    });

    it('should return "Hurry only X tickets left!" if ticketsRemaining is less than minimumTicketCount', () => {
      const event = new Event(1, 'Concert', 10, 10, 2, new Date());
      expect(getTagLine(event, 5, false)).toBe('Hurry only 2 tickets left!');
    });

    it('should return "Hurry only 1 ticket left!" if ticketsRemaining is 1', () => {
      const event = new Event(1, 'Concert', 10, 10, 1, new Date());
      expect(getTagLine(event, 5, false)).toBe('Hurry only 1 ticket left!');
    });

    it('should return "This Event is getting a lot of interest. Don\'t miss out, purchase your ticket now!" if event is popular and ticketsRemaining is greater than minimumTicketCount', () => {
      const event = new Event(1, 'Concert', 10, 10, 10, new Date());
      expect(getTagLine(event, 5, true)).toBe('This Event is getting a lot of interest. Don\'t miss out, purchase your ticket now!');
    });

    it('should return "Don\'t miss out, purchase your ticket now!" if event is not popular and ticketsRemaining is greater than minimumTicketCount', () => {
      const event = new Event(1, 'Concert', 10, 10, 10, new Date());
      expect(getTagLine(event, 5, false)).toBe('Don\'t miss out, purchase your ticket now!');
    });
  });

  describe('createEvent', () => {
    it('should create a new Event object with valid parameters', () => {
      const name = 'Concert';
      const price = 10;
      const availableTickets = 10;
      const event = createEvent(name, price, availableTickets);

      expect(event).toBeInstanceOf(Event);
      expect(event.name).toBe(name);
      expect(event.ticketPrice).toBe(price);
      expect(event.totalTickets).toBe(availableTickets);
    });

    it('should throw an InvalidEventNameError if name is not a string or exceeds 200 characters', () => {
      expect(() => createEvent(123, 10, 10)).toThrowError(InvalidEventNameError);
      expect(() => createEvent(''.padEnd(201, 'a'), 10, 10)).toThrowError(InvalidEventNameError);
    });

    it('should throw an InvalidEventPriceError if price is not a number or less than 0', () => {
      expect(() => createEvent('Concert', '10', 10)).toThrowError(InvalidEventPriceError);
      expect(() => createEvent('Concert', -1, 10)).toThrowError(InvalidEventPriceError);
    });

    it('should throw an InvalidEventPriceError if availableTickets is not a number or less than 1', () => {
      expect(() => createEvent('Concert', 10, '10')).toThrowError(InvalidEventPriceError);
      expect(() => createEvent('Concert', 10, 0)).toThrowError(InvalidEventPriceError);
    });
  });
});