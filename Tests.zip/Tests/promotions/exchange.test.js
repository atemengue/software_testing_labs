import { describe, it, expect, vi } from 'vitest';
import getExchangeRate from '../../js/promotions/exchange/exchange';
import exchangeRateProvider from '../../js/promotions/exchange/exchangeRateProvider';

describe('Exchange Rate', () => {
  
  it('should return the correct exchange rate for USD', async () => {
    const currencyCode = 'USD';
    const mockCallback = vi.fn();
    await getExchangeRate(currencyCode, mockCallback);

    expect(mockCallback).toHaveBeenCalledWith({
      originalCurrency: 'GBP',
      newCurrency: 'USD',
      exchangeRate: 1.25,
    });
  });

  it('should return the correct exchange rate for EUR', async () => {
    const currencyCode = 'EUR';
    const mockCallback = vi.fn();
    await getExchangeRate(currencyCode, mockCallback);

    expect(mockCallback).toHaveBeenCalledWith({
      originalCurrency: 'GBP',
      newCurrency: 'EUR',
      exchangeRate: 1.18,
    });
  });

  it('should return the correct exchange rate for NZD', async () => {
    const currencyCode = 'NZD';
    const mockCallback = vi.fn();
    await getExchangeRate(currencyCode, mockCallback);

    expect(mockCallback).toHaveBeenCalledWith({
      originalCurrency: 'GBP',
      newCurrency: 'NZD',
      exchangeRate: 1.93,
    });
  });

  it('should throw an error if the currency is not supported', async () => {
    const currencyCode = 'JPY';
    const mockCallback = vi.fn();

    await expect(getExchangeRate(currencyCode, mockCallback)).rejects.toThrowError(
      'Currency not supported'
    );
  });
});