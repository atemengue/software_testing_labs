import { describe, it, expect, vi } from 'vitest';
import * as promotions from '../../js/promotions/promotions';
import { getDiscount } from '../../js/promotions/discount/discount';

// Moquer axios pour les tests
vi.mock('axios');

describe('Promotions', () => {
  describe('calculatePercentageDiscount', () => {
    it('should apply the discount if the current price meets the minimum spend', () => {
      const percentage = 10;
      const minimumSpend = 50;
      const currentPrice = 60;
      const expectedDiscount = 5.4;

      const discountedPrice = promotions.calculatePercentageDiscount(percentage, minimumSpend, currentPrice);

      expect(discountedPrice).toBe(expectedDiscount);
    });

    it('should not apply the discount if the current price is below the minimum spend', () => {
      const percentage = 10;
      const minimumSpend = 50;
      const currentPrice = 40;

      const discountedPrice = promotions.calculatePercentageDiscount(percentage, minimumSpend, currentPrice);

      expect(discountedPrice).toBe(currentPrice);
    });
  });

  describe('calculateMoneyOff', () => {
    it('should apply the discount if the current price meets the minimum spend', () => {
      const discount = 5;
      const minimumSpend = 50;
      const currentPrice = 60;
      const expectedPrice = 55;

      const discountedPrice = promotions.calculateMoneyOff(discount, minimumSpend, currentPrice);

      expect(discountedPrice).toBe(expectedPrice);
    });

    it('should not apply the discount if the current price is below the minimum spend', () => {
      const discount = 5;
      const minimumSpend = 50;
      const currentPrice = 40;

      const discountedPrice = promotions.calculateMoneyOff(discount, minimumSpend, currentPrice);

      expect(discountedPrice).toBe(currentPrice);
    });
  });

  describe('generateReferralCode', () => {
    it('should generate a unique referral code', () => {
      const userId = 123;
      const referralCode = promotions.generateReferralCode(userId);

      expect(referralCode).toMatch(/#FRIEND-#\d{3}-#123/);
    });
  });

  describe('applyDiscount', () => {
    it('should apply a MONEYOFF discount if the discount code is valid', async () => {
      const discountCode = 'TEST-MONEYOFF';
      const currentTotal = 100;
      const mockDiscountData = {
        isValid: true,
        type: 'MONEYOFF',
        value: 10,
        minSpend: 50,
      };

      // Moquer la réponse de getDiscount
      vi.mocked(getDiscount).mockResolvedValue({
        data: mockDiscountData,
      });

      const discountedTotal = await promotions.applyDiscount(discountCode, currentTotal);

      expect(discountedTotal).toBe(90);
    });

    it('should apply a PERCENTAGEOFF discount if the discount code is valid', async () => {
      const discountCode = 'TEST-PERCENTAGEOFF';
      const currentTotal = 100;
      const mockDiscountData = {
        isValid: true,
        type: 'PERCENTAGEOFF',
        value: 10,
        minSpend: 50,
      };

      // Moquer la réponse de getDiscount
      vi.mocked(getDiscount).mockResolvedValue({
        data: mockDiscountData,
      });

      const discountedTotal = await promotions.applyDiscount(discountCode, currentTotal);

      expect(discountedTotal).toBe(90);
    });

    it('should return the original total if the discount code is invalid', async () => {
      const discountCode = 'INVALID-CODE';
      const currentTotal = 100;
      const mockDiscountData = {
        isValid: false,
      };

      // Moquer la réponse de getDiscount
      vi.mocked(getDiscount).mockResolvedValue({
        data: mockDiscountData,
      });

      const discountedTotal = await promotions.applyDiscount(discountCode, currentTotal);

      expect(discountedTotal).toBe(currentTotal);
    });
  });
});